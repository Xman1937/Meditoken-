# MediToken
1. **Supabase project:** create one at supabase.com.
2. **Env vars:** copy `.env.example` to `.env` (Replit: Tools → Secrets) and set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` (Project Settings → API → anon key). Never use the service-role key.
3. **Schema + RLS + storage:** run `supabase/schema.sql` in the SQL editor (RLS is enabled on every table). For test data only, also run `supabase/seed.sql`.
4. **First admin:** Authentication → Users → Add user (email/password). Copy its UID, then run: `insert into profiles(user_id,role,name) values('<UID>','admin','Admin');`
5. **Replit:** `npm install && npm run dev`.
6. **Netlify:** connect the repo, build `npm run build`, publish `dist`, add the two env vars. `netlify.toml` already has the SPA redirect.

## Doctor accounts (Phase 3)
- Existing database? Run `supabase/migration_phase3.sql` once (adds `doctors.address`).
- Doctors register at `/doctor/register` (status = pending) and log in at `/doctor/login`. If Supabase email confirmation is ON, they confirm the email first; their profile is created automatically at first login.
- In Supabase → Authentication → URL Configuration, add your Netlify URL as Site URL.
