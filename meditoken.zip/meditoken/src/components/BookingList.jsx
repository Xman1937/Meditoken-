import { useState } from 'react'
import { supabase } from '../supabase.js'
import { fmtDate, t12 } from '../utils.js'
const ACTIONS = [['waiting','Mark Waiting'],['completed','Mark Completed'],['cancelled','Cancel'],['no_show','No Show']]
export default function BookingList({rows,schedules=[],onChange,showDate}){
  const [busy,setBusy] = useState(null), [err,setErr] = useState('')
  const act = async (b,s) => {
    if(s==='cancelled' && !confirm('Cancel this booking?')) return
    setBusy(b.id); setErr('')
    const {error} = await supabase.from('bookings').update({booking_status:s}).eq('id',b.id)
    setBusy(null); if(error) setErr('Could not update the status. Please try again.'); else onChange() }
  if(!rows.length) return <p className="muted pad">No bookings found.</p>
  const slot = d => { const s = schedules.find(x=>x.day_of_week===new Date(d+'T00:00:00').getDay()); return s?`${t12(s.start_time)}–${t12(s.end_time)}`:'—' }
  return <div>{err&&<p className="err">{err}</p>}{rows.map(b=><div className="bk" key={b.id}>
    <div className="bkt">{String(b.token_number).padStart(2,'0')}</div>
    <div className="bki"><b>{b.patient_name}</b> <span className={'st st-'+b.booking_status}>{b.booking_status.replace('_',' ')}</span>
      <p className="muted">📞 {b.patient_mobile} · {b.patient_age} yrs · {b.patient_gender} · 🕒 {slot(b.booking_date)}{showDate&&` · ${fmtDate(b.booking_date)}`}</p>
      {b.symptoms&&<p className="muted">“{b.symptoms}”</p>}</div>
    <div className="acts">{ACTIONS.filter(([s])=>s!==b.booking_status).map(([s,l])=><button key={s} className="btn sm ghost" disabled={busy===b.id} onClick={()=>act(b,s)}>{l}</button>)}</div></div>)}</div>
}
