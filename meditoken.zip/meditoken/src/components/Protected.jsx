import { Navigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext.jsx'
export default function Protected({role,children}){
  const {user,role:r,loading} = useAuth()
  if(loading) return <p className="muted pad wrap">Loading…</p>
  if(!user||r!==role) return <Navigate to={`/${role}/login`} replace/>
  return children
}
