import { createContext, useContext, useEffect, useState } from 'react'
import { supabase } from '../supabase.js'
const Ctx = createContext(null)
export const useAuth = () => useContext(Ctx)
export function AuthProvider({children}){
  const [user,setUser] = useState(null), [role,setRole] = useState(null), [loading,setLoading] = useState(true)
  const load = async u => {
    if(!u){ setUser(null); setRole(null); setLoading(false); return }
    const {data} = await supabase.from('profiles').select('role').eq('user_id',u.id).maybeSingle()
    setUser(u); setRole(data?.role||null); setLoading(false) }
  useEffect(()=>{
    supabase.auth.getSession().then(({data})=>load(data.session?.user))
    const {data:sub} = supabase.auth.onAuthStateChange((_e,s)=>{ setTimeout(()=>load(s?.user),0) })
    return ()=>sub.subscription.unsubscribe() },[])
  const reload = () => supabase.auth.getUser().then(({data})=>load(data.user))
  return <Ctx.Provider value={{user,role,loading,reload,signOut:()=>supabase.auth.signOut()}}>{children}</Ctx.Provider>
}
