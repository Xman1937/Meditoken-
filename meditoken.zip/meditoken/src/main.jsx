import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.jsx'
import { AuthProvider } from './contexts/AuthContext.jsx'
import { configured } from './supabase.js'
import './styles.css'
createRoot(document.getElementById('root')).render(configured
  ? <BrowserRouter><AuthProvider><App/></AuthProvider></BrowserRouter>
  : <div className="wrap page"><h1>Setup needed</h1><p>Add <b>VITE_SUPABASE_URL</b> and <b>VITE_SUPABASE_ANON_KEY</b> as environment variables (Replit Secrets or .env) and restart. See README.</p></div>)
