export const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']
export const t12 = t => { if(!t) return ''; const [h,m] = t.split(':'); const H = +h; return `${H%12||12}:${m} ${H<12?'AM':'PM'}` }
export const hours = c => c.opening_time ? `${t12(c.opening_time)} – ${t12(c.closing_time)}` : '—'
export const schedText = d => (d.doctor_schedules||[]).filter(s=>s.is_active).sort((a,b)=>a.day_of_week-b.day_of_week).map(s=>`${DAYS[s.day_of_week]} ${t12(s.start_time)}–${t12(s.end_time)}`).join(', ') || 'Not scheduled'
export const fmtDate = d => new Date(d+'T00:00:00').toLocaleDateString('en-GB',{day:'2-digit',month:'long',year:'numeric'})
const ERR = {
  TOKEN_TAKEN:'That token was just booked by another patient. Please select another token.',
  NOT_AVAILABLE:'This doctor is not available for booking on this date.',
  INVALID_DATE:'Please choose a valid upcoming date.',
  INVALID_TOKEN:'Please select a valid token.',
  INVALID_MOBILE:'This mobile number is not valid.',
  INVALID_DETAILS:'Please check the patient details and try again.'}
export const friendly = e => { const m = e?.message||''; for (const k in ERR) if (m.includes(k)) return ERR[k]; return 'Booking could not be completed. Please try again.' }
