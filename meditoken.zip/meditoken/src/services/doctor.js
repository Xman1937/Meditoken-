import { supabase } from '../supabase.js'
// Creates profile + doctor + schedule rows from signup metadata (works even when e-mail confirmation delays the first session)
export async function ensureDoctor(user){
  const m = user.user_metadata?.doctor; if(!m) return
  const {data:ex} = await supabase.from('profiles').select('id').eq('user_id',user.id).maybeSingle()
  if(ex) return
  const p = await supabase.from('profiles').insert({user_id:user.id,role:'doctor',name:m.name,mobile:m.mobile,email:user.email})
  if(p.error) throw p.error
  const {data:d,error} = await supabase.from('doctors').insert({user_id:user.id,clinic_id:m.clinic_id,name:m.name,mobile:m.mobile,email:user.email,specialization:m.specialization,qualification:m.qualification,experience:m.experience,license_number:m.license,address:m.address,status:'pending'}).select('id').single()
  if(error) throw error
  const rows = (m.days||[]).map(day=>({doctor_id:d.id,day_of_week:day,start_time:m.start,end_time:m.end,token_limit:30}))
  if(rows.length) await supabase.from('doctor_schedules').insert(rows)
}
export async function uploadImage(bucket,folder,file){
  if(!file.type.startsWith('image/')) throw new Error('Please choose an image file.')
  if(file.size>2*1024*1024) throw new Error('Image must be smaller than 2 MB.')
  const path = `${folder}/${Date.now()}.${file.name.split('.').pop()}`
  const {error} = await supabase.storage.from(bucket).upload(path,file,{upsert:true})
  if(error) throw new Error('Image upload failed. Please try again.')
  return supabase.storage.from(bucket).getPublicUrl(path).data.publicUrl
}
