import { useEffect, useState } from 'react'
import { supabase } from '../supabase.js'
export const About = () => <div className="wrap page narrow"><h1>About MediToken</h1>
  <p>MediToken is a clinic token booking platform. Patients pick a clinic, doctor and date, choose a token and get a digital receipt, with no account needed.</p>
  <h3>For patients</h3><p>Book in a minute, see which tokens are free, and look your booking up later with your mobile number or Booking ID.</p>
  <h3>For doctors</h3><p>Register, get approved, set your weekly schedule and token limits, and manage the day's patients from one dashboard.</p>
  <h3>For clinics</h3><p>Admins manage clinics, doctors and bookings in one place and control token settings.</p></div>
const FAQ = [['How do I book a token?','Go to Book Token, choose a clinic, doctor and date, tap an available token, enter the patient details and confirm.'],['Do I need to login?','No. Patients never need an account.'],['How can I find my token?','Open Find Token and enter your mobile number or Booking ID.'],['How can I cancel a booking?','Please contact the clinic using the contact details on the Settings page; the clinic can cancel it for you.'],['How does doctor registration work?','Doctors register with their details. An admin reviews and approves the registration before the doctor appears for bookings.'],['How can a doctor check bookings?','Log in at Doctor Login to see today’s tokens and upcoming bookings.'],['How can a clinic contact support?','Use the contact number or support email on the Settings page.']]
export const Help = () => <div className="wrap page narrow"><h1>Help</h1>{FAQ.map(([q,a])=><details key={q} className="faq"><summary>{q}</summary><p>{a}</p></details>)}</div>
export function PublicSettings(){
  const [a,setA] = useState(null)
  useEffect(()=>{ supabase.from('admin_settings').select('site_name,contact_number,support_email').eq('id',1).maybeSingle().then(({data})=>setA(data)) },[])
  return <div className="wrap page narrow"><h1>Settings</h1><div className="bcard"><h3 className="h3">Contact</h3>
    <p>📞 {a?.contact_number||'Not provided yet'}</p><p>✉️ {a?.support_email||'Not provided yet'}</p></div></div>
}
