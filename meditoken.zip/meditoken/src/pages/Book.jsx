import { useEffect, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { supabase, today } from '../supabase.js'
import { friendly, schedText, t12 } from '../utils.js'
const pad = n => String(n).padStart(2,'0')
export default function Book(){
  const [sp] = useSearchParams(), nav = useNavigate()
  const [clinics,setClinics] = useState([]), [docs,setDocs] = useState([])
  const [clinic,setClinic] = useState(sp.get('clinic')||''), [doctor,setDoctor] = useState(sp.get('doctor')||''), [date,setDate] = useState(sp.get('date')||today())
  const [board,setBoard] = useState(undefined), [token,setToken] = useState(null)
  const [p,setP] = useState({name:'',mobile:'',age:'',gender:'',symptoms:''}), [err,setErr] = useState(''), [busy,setBusy] = useState(false)
  const d = docs.find(x=>x.id===doctor)
  const loadBoard = () => { if(!doctor||!date){setBoard(undefined);return}
    setBoard('loading'); supabase.rpc('get_token_board',{p_doctor:doctor,p_date:date}).then(({data,error})=>setBoard(error?'error':data)) }
  useEffect(()=>{supabase.from('clinics').select('id,name').eq('is_active',true).order('name').then(({data})=>setClinics(data||[]))},[])
  useEffect(()=>{ if(!clinic){setDocs([]);return}
    supabase.from('doctors').select('*,doctor_schedules(*)').eq('clinic_id',clinic).eq('status','approved').eq('is_active',true)
      .then(({data})=>{setDocs(data||[]); if(!(data||[]).some(x=>x.id===doctor)) setDoctor('')}) },[clinic])
  useEffect(()=>{setToken(null);loadBoard()},[doctor,date])
  const submit = async e => { e.preventDefault(); setErr('')
    if(!clinic) return setErr('Please select a clinic.')
    if(!doctor) return setErr('Please select a doctor.')
    if(!token) return setErr('Please select a token.')
    if(p.name.trim().length<2) return setErr('Please enter the patient name.')
    if(!/^\+?\d{10,13}$/.test(p.mobile.trim())) return setErr('This mobile number is not valid.')
    if(p.age===''||+p.age<0||+p.age>120) return setErr('Please enter a valid age.')
    if(!p.gender) return setErr('Please select gender.')
    setBusy(true)
    const {data,error} = await supabase.rpc('book_token',{p_doctor:doctor,p_date:date,p_token:token,p_name:p.name,p_mobile:p.mobile.trim(),p_age:+p.age,p_gender:p.gender,p_symptoms:p.symptoms})
    setBusy(false)
    if(error){ setErr(friendly(error)); if((error.message||'').includes('TOKEN_TAKEN')){setToken(null);loadBoard()} return }
    nav(`/booking-success/${data}`) }
  const ok = board && typeof board==='object', free = ok ? board.limit-board.booked.length : 0
  return <div className="wrap page narrow"><h1>Book Token</h1>
  <form className="bcard" onSubmit={submit} noValidate>
    <label>1. Clinic<select value={clinic} onChange={e=>setClinic(e.target.value)}><option value="">Select Clinic</option>{clinics.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
    <label>2. Doctor<select value={doctor} onChange={e=>setDoctor(e.target.value)}><option value="">Select Doctor</option>{docs.map(x=><option key={x.id} value={x.id}>{x.name} – {x.specialization}</option>)}</select></label>
    <label>3. Date<input type="date" min={today()} value={date} onChange={e=>setDate(e.target.value)}/></label>
    {board==='loading'&&<p className="info">Loading tokens…</p>}
    {board==='error'&&<p className="err">Could not load tokens. Please try again.</p>}
    {board===null&&<p className="info">The doctor is not available on this date.<br/>Schedule: {d?schedText(d):''}</p>}
    {ok&&<><p className="info">🕒 {t12(board.start)} – {t12(board.end)} · {free>0?`${free} of ${board.limit} tokens available`:'No tokens are available for this date.'}</p>
      <div className="tokens">{Array.from({length:board.limit},(_,i)=>i+1).map(n=>{const b=board.booked.includes(n)
        return <button type="button" key={n} disabled={b} className={'tk'+(token===n?' sel':'')} onClick={()=>setToken(n)}><b>{pad(n)}</b><span>{b?'Booked':'Available'}</span></button>})}</div></>}
    {ok&&token&&<><h3 className="h3">4. Patient details — Token {pad(token)}</h3>
      <label>Patient name<input autoComplete="name" value={p.name} onChange={e=>setP({...p,name:e.target.value})}/></label>
      <label>Mobile number<input type="tel" inputMode="tel" autoComplete="tel" value={p.mobile} onChange={e=>setP({...p,mobile:e.target.value})}/></label>
      <div className="two"><label>Age<input type="number" inputMode="numeric" min="0" max="120" value={p.age} onChange={e=>setP({...p,age:e.target.value})}/></label>
      <label>Gender<select value={p.gender} onChange={e=>setP({...p,gender:e.target.value})}><option value="">Select</option><option value="male">Male</option><option value="female">Female</option><option value="other">Other</option></select></label></div>
      <label>Symptoms / reason (optional)<textarea rows="2" value={p.symptoms} onChange={e=>setP({...p,symptoms:e.target.value})}/></label></>}
    {err&&<p className="err" role="alert">{err}</p>}
    <button className="btn" disabled={busy||!ok||free===0}>{busy?'Booking token…':'Confirm Booking'}</button>
  </form></div>
}
