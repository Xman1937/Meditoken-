import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { supabase } from '../supabase.js'
import { hours } from '../utils.js'
import { DoctorCard, Img, State } from '../components.jsx'
export default function ClinicDetail(){
  const {clinicId}=useParams(),[c,setC]=useState(null),[docs,setDocs]=useState([]),[err,setErr]=useState(''),[ld,setLd]=useState(true)
  useEffect(()=>{(async()=>{
    const a=await supabase.from('clinics').select('*').eq('id',clinicId).eq('is_active',true).maybeSingle()
    const b=await supabase.from('doctors').select('*,doctor_schedules(*)').eq('clinic_id',clinicId).eq('status','approved').eq('is_active',true)
    setC(a.data);setDocs(b.data||[]);setErr((a.error||b.error)?'Could not load clinic. Please try again.':'');setLd(false)})()},[clinicId])
  if(ld||err||!c)return <div className="wrap"><State loading={ld} error={err} empty={!ld&&!err&&!c&&'Clinic not found.'}/></div>
  return <div className="wrap page"><div className="detail"><div className="imgbox"><Img src={c.image_url} alt={c.name}/></div>
    <div><h1>{c.name}</h1><p>{c.description}</p><p>📍 {[c.address,c.city,c.state].filter(Boolean).join(', ')}</p><p>📞 {c.phone||'—'}</p><p>🕒 {hours(c)}</p>
    <Link className="btn" to={`/book?clinic=${c.id}`}>Book Token</Link></div></div>
    <h2>Available Doctors</h2><State empty={!docs.length&&'No doctors available right now.'}/>
    <div className="grid">{docs.map(d=><DoctorCard key={d.id} d={d}/>)}</div></div>
}
