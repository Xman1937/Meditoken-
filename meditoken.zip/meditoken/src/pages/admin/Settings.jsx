import { useEffect, useState } from 'react'
import { supabase } from '../../supabase.js'
import { uploadImage } from '../../services/doctor.js'
export default function Settings(){
  const [t,setT] = useState(null), [a,setA] = useState(null), [msg,setMsg] = useState(''), [busy,setBusy] = useState(false)
  useEffect(()=>{ supabase.from('token_settings').select('*').eq('id',1).single().then(({data})=>setT(data)); supabase.from('admin_settings').select('*').eq('id',1).single().then(({data})=>setA(data)) },[])
  const logo = async e => { const f = e.target.files[0]; if(!f) return; try{ setA({...a,logo_url:await uploadImage('clinic-images','site',f)}) }catch(ex){ setMsg(ex.message) } }
  const save = async e => { e.preventDefault(); setMsg('')
    if(!(+t.default_token_limit>0)||!(+t.booking_days_ahead>0)) return setMsg('Token limit and booking days must be at least 1.')
    setBusy(true)
    const r1 = await supabase.from('token_settings').update({default_token_limit:+t.default_token_limit,booking_days_ahead:+t.booking_days_ahead,bookings_open:t.bookings_open}).eq('id',1)
    const r2 = await supabase.from('admin_settings').update({site_name:a.site_name,logo_url:a.logo_url,contact_number:a.contact_number,support_email:a.support_email}).eq('id',1)
    setBusy(false); setMsg(r1.error||r2.error?'Could not save settings. Please try again.':'Settings saved.') }
  if(!t||!a) return <p className="muted pad">Loading settings…</p>
  return <><h1>Settings</h1><form className="bcard" onSubmit={save} noValidate><h3 className="h3">Token settings</h3>
    <div className="two"><label>Default token limit<input type="number" min="1" value={t.default_token_limit} onChange={e=>setT({...t,default_token_limit:e.target.value})}/></label><label>Bookable days ahead<input type="number" min="1" value={t.booking_days_ahead} onChange={e=>setT({...t,booking_days_ahead:e.target.value})}/></label></div>
    <label className="chk"><input type="checkbox" checked={t.bookings_open} onChange={e=>setT({...t,bookings_open:e.target.checked})}/> Bookings open (untick to pause all booking)</label>
    <h3 className="h3">Website</h3><label>Website name<input value={a.site_name||''} onChange={e=>setA({...a,site_name:e.target.value})}/></label>
    <label>Logo<input type="file" accept="image/*" onChange={logo}/></label>{a.logo_url&&<img src={a.logo_url} alt="Logo" style={{height:48,objectFit:'contain'}}/>}
    <div className="two"><label>Contact number<input type="tel" value={a.contact_number||''} onChange={e=>setA({...a,contact_number:e.target.value})}/></label><label>Support email<input type="email" value={a.support_email||''} onChange={e=>setA({...a,support_email:e.target.value})}/></label></div>
    {msg&&<p className={msg==='Settings saved.'?'info':'err'}>{msg}</p>}<button className="btn" disabled={busy}>{busy?'Saving…':'Save Settings'}</button></form></>
}
