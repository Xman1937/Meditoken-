import { useEffect, useState } from 'react'
import { supabase } from '../../supabase.js'
import { uploadImage } from '../../services/doctor.js'
import { hours, fmtDate } from '../../utils.js'
import { Img } from '../../components.jsx'
const EMPTY = {name:'',address:'',city:'',state:'',phone:'',email:'',description:'',opening_time:'09:00',closing_time:'18:00',image_url:'',is_active:true}
function Form({c,onDone,onCancel}){
  const [f,setF] = useState({...EMPTY,...c,opening_time:(c.opening_time||'09:00').slice(0,5),closing_time:(c.closing_time||'18:00').slice(0,5)}), [msg,setMsg] = useState(''), [busy,setBusy] = useState(false), [up,setUp] = useState(false)
  const set = k => e => setF({...f,[k]:e.target.value})
  const pick = async e => { const file = e.target.files[0]; if(!file) return; setUp(true); setMsg('')
    try{ setF({...f,image_url:await uploadImage('clinic-images','clinics',file)}) }catch(ex){ setMsg(ex.message) } setUp(false) }
  const save = async e => { e.preventDefault(); setMsg('')
    if(!f.name.trim()||!f.city.trim()) return setMsg('Clinic name and city are required.')
    if(f.closing_time<=f.opening_time) return setMsg('Closing time must be after opening time.')
    setBusy(true); const {id,created_at,updated_at,...body} = f
    const {error} = id ? await supabase.from('clinics').update(body).eq('id',id) : await supabase.from('clinics').insert(body)
    setBusy(false); if(error) setMsg('Could not save the clinic. Please try again.'); else onDone() }
  return <form className="bcard" onSubmit={save} noValidate><h3 className="h3">{f.id?'Edit clinic':'New clinic'}</h3>
    <div className="imgbox" style={{borderRadius:12}}><Img src={f.image_url} alt="Clinic"/></div>
    <label>{up?'Uploading image…':'Clinic image (max 2 MB)'}<input type="file" accept="image/*" disabled={up} onChange={pick}/></label>
    <label>Name<input value={f.name} onChange={set('name')}/></label><label>Address<input value={f.address||''} onChange={set('address')}/></label>
    <div className="two"><label>City<input value={f.city} onChange={set('city')}/></label><label>State<input value={f.state||''} onChange={set('state')}/></label></div>
    <div className="two"><label>Phone<input type="tel" value={f.phone||''} onChange={set('phone')}/></label><label>Email<input type="email" value={f.email||''} onChange={set('email')}/></label></div>
    <div className="two"><label>Opens<input type="time" value={f.opening_time} onChange={set('opening_time')}/></label><label>Closes<input type="time" value={f.closing_time} onChange={set('closing_time')}/></label></div>
    <label>Description<textarea rows="2" value={f.description||''} onChange={set('description')}/></label>
    <label className="chk"><input type="checkbox" checked={f.is_active} onChange={e=>setF({...f,is_active:e.target.checked})}/> Active</label>
    {msg&&<p className="err" role="alert">{msg}</p>}<div className="row2"><button className="btn" disabled={busy||up}>{busy?'Saving…':'Save Clinic'}</button><button type="button" className="btn ghost" onClick={onCancel}>Cancel</button></div></form>
}
export default function Clinics(){
  const [rows,setRows] = useState(null), [q,setQ] = useState(''), [edit,setEdit] = useState(null), [err,setErr] = useState('')
  const load = () => supabase.from('clinics').select('*').order('name').then(({data,error})=>{setRows(data||[]);setErr(error?'Could not load clinics.':'')})
  useEffect(()=>{load()},[])
  const toggle = async c => { const {error} = await supabase.from('clinics').update({is_active:!c.is_active}).eq('id',c.id); if(error) setErr('Could not update the clinic.'); else load() }
  if(edit) return <Form c={edit} onCancel={()=>setEdit(null)} onDone={()=>{setEdit(null);load()}}/>
  const list = (rows||[]).filter(c=>(c.name+c.city).toLowerCase().includes(q.toLowerCase()))
  return <><div className="row2 sp"><h1>Clinics</h1><button className="btn sm" onClick={()=>setEdit({})}>+ Add Clinic</button></div>
    <input placeholder="Search clinic…" value={q} onChange={e=>setQ(e.target.value)}/>{err&&<p className="err">{err}</p>}
    {rows===null?<p className="muted pad">Loading clinics…</p>:!list.length?<p className="muted pad">No clinics found.</p>:list.map(c=><div className="bk" key={c.id} style={{gridTemplateColumns:'64px 1fr'}}>
      <div className="imgbox" style={{height:64,borderRadius:10}}><Img src={c.image_url} alt={c.name}/></div>
      <div className="bki"><b>{c.name}</b> <span className={'st'+(c.is_active?'':' st-cancelled')}>{c.is_active?'active':'inactive'}</span>
        <p className="muted">📍 {[c.address,c.city,c.state].filter(Boolean).join(', ')} · 🕒 {hours(c)} · 📞 {c.phone||'—'}</p></div>
      <div className="acts"><button className="btn sm ghost" onClick={()=>setEdit(c)}>Edit</button><button className="btn sm ghost" onClick={()=>toggle(c)}>{c.is_active?'Deactivate':'Activate'}</button></div></div>)}</>
}
