import { useEffect, useState } from 'react'
import { supabase, today } from '../../supabase.js'
const cnt = async (t,f=x=>x) => { const {count,error} = await f(supabase.from(t).select('id',{count:'exact',head:true})); if(error) throw error; return count||0 }
export default function Dashboard(){
  const [s,setS] = useState(null), [err,setErr] = useState('')
  useEffect(()=>{ Promise.all([cnt('clinics'),cnt('doctors'),cnt('doctors',q=>q.eq('status','pending')),cnt('bookings',q=>q.eq('booking_date',today())),cnt('bookings'),cnt('bookings',q=>q.eq('booking_status','completed')),cnt('bookings',q=>q.eq('booking_status','cancelled'))])
    .then(setS).catch(()=>setErr('Could not load statistics.')) },[])
  const L = ['Total Clinics','Total Doctors','Pending Doctors',"Today's Bookings",'Total Bookings','Completed','Cancelled']
  return <><h1>Dashboard</h1>{err&&<p className="err">{err}</p>}<div className="stats">{L.map((l,i)=><div className="stat" key={l}><b>{s?s[i]:'…'}</b>{l}</div>)}</div></>
}
