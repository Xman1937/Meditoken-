import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../supabase.js'
import { useAuth } from '../../contexts/AuthContext.jsx'
export default function AdminLogin(){
  const [email,setEmail] = useState(''), [password,setPassword] = useState(''), [err,setErr] = useState(''), [busy,setBusy] = useState(false)
  const {reload} = useAuth(), nav = useNavigate()
  const submit = async e => { e.preventDefault(); setErr(''); setBusy(true)
    const {data,error} = await supabase.auth.signInWithPassword({email:email.trim(),password})
    if(error){ setBusy(false); return setErr('Invalid email or password.') }
    const {data:pr} = await supabase.from('profiles').select('role').eq('user_id',data.user.id).maybeSingle()
    if(pr?.role!=='admin'){ await supabase.auth.signOut(); setBusy(false); return setErr('This is not an admin account.') }
    await reload(); nav('/admin/dashboard') }
  return <div className="wrap page narrow"><h1>Admin Login</h1><form className="bcard" onSubmit={submit}>
    <label>Email<input type="email" required autoComplete="username" value={email} onChange={e=>setEmail(e.target.value)}/></label>
    <label>Password<input type="password" required autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)}/></label>
    {err&&<p className="err" role="alert">{err}</p>}<button className="btn" disabled={busy}>{busy?'Signing in…':'Login'}</button></form></div>
}
