import { useEffect, useState } from 'react'
import { supabase } from '../../supabase.js'
import { fmtDate } from '../../utils.js'
const STATUSES = ['booked','confirmed','waiting','completed','cancelled','no_show']
export default function Bookings(){
  const [f,setF] = useState({date:'',clinic:'',doctor:'',status:'',mobile:'',token:''}), [rows,setRows] = useState(null), [clinics,setClinics] = useState([]), [docs,setDocs] = useState([]), [err,setErr] = useState('')
  useEffect(()=>{ supabase.from('clinics').select('id,name').order('name').then(({data})=>setClinics(data||[])); supabase.from('doctors').select('id,name').order('name').then(({data})=>setDocs(data||[])) },[])
  const load = async () => { setRows(null)
    let q = supabase.from('bookings').select('*,doctors(name),clinics(name)').order('booking_date',{ascending:false}).order('token_number').limit(200)
    if(f.date) q = q.eq('booking_date',f.date); if(f.clinic) q = q.eq('clinic_id',f.clinic); if(f.doctor) q = q.eq('doctor_id',f.doctor)
    if(f.status) q = q.eq('booking_status',f.status); if(f.mobile.trim()) q = q.ilike('patient_mobile',`%${f.mobile.trim().replace(/[%_]/g,'')}%`); if(f.token) q = q.eq('token_number',+f.token)
    const {data,error} = await q; setErr(error?'Could not load bookings.':''); setRows(data||[]) }
  useEffect(()=>{ const t = setTimeout(load,300); return ()=>clearTimeout(t) },[f])
  const setStatus = async (b,s) => { if(s==='cancelled'&&!confirm('Cancel this booking?')) return
    const {error} = await supabase.from('bookings').update({booking_status:s}).eq('id',b.id); if(error) setErr('Could not update the status.'); else load() }
  const set = k => e => setF({...f,[k]:e.target.value})
  return <><h1>Bookings</h1><div className="fl">
    <input type="date" value={f.date} onChange={set('date')}/><select value={f.clinic} onChange={set('clinic')}><option value="">All clinics</option>{clinics.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select>
    <select value={f.doctor} onChange={set('doctor')}><option value="">All doctors</option>{docs.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select>
    <select value={f.status} onChange={set('status')}><option value="">All statuses</option>{STATUSES.map(s=><option key={s} value={s}>{s.replace('_',' ')}</option>)}</select>
    <input placeholder="Mobile number" value={f.mobile} onChange={set('mobile')}/><input type="number" min="1" placeholder="Token no." value={f.token} onChange={set('token')}/></div>
    {err&&<p className="err">{err}</p>}{rows===null?<p className="muted pad">Loading bookings…</p>:!rows.length?<p className="muted pad">No bookings found.</p>:rows.map(b=><div className="bk" key={b.id}>
      <div className="bkt">{String(b.token_number).padStart(2,'0')}</div>
      <div className="bki"><b>{b.patient_name}</b> <span className={'st st-'+b.booking_status}>{b.booking_status.replace('_',' ')}</span>
        <p className="muted">📞 {b.patient_mobile} · {b.clinics?.name} · {b.doctors?.name}</p><p className="muted">📅 {fmtDate(b.booking_date)} · ID MT-{b.id.replace(/-/g,'').slice(0,8).toUpperCase()} · booked {new Date(b.created_at).toLocaleString()}</p></div>
      <div className="acts"><select value={b.booking_status} onChange={e=>setStatus(b,e.target.value)} style={{width:'auto'}}>{STATUSES.map(s=><option key={s} value={s}>{s.replace('_',' ')}</option>)}</select>
        {b.booking_status!=='cancelled'&&<button className="btn sm ghost" onClick={()=>setStatus(b,'cancelled')}>Cancel Booking</button>}</div></div>)}</>
}
