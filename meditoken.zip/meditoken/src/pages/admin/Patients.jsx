import { useEffect, useState } from 'react'
import { supabase } from '../../supabase.js'
import { fmtDate } from '../../utils.js'
export default function Patients(){
  const [rows,setRows] = useState(null), [q,setQ] = useState(''), [err,setErr] = useState('')
  useEffect(()=>{ supabase.from('bookings').select('patient_name,patient_mobile,patient_age,patient_gender,booking_date').order('booking_date',{ascending:false}).limit(1000).then(({data,error})=>{
    const m = new Map(); (data||[]).forEach(b=>{ const p = m.get(b.patient_mobile); if(p) p.visits++; else m.set(b.patient_mobile,{...b,visits:1}) })
    setRows([...m.values()]); setErr(error?'Could not load patients.':'') }) },[])
  const list = (rows||[]).filter(p=>(p.patient_name+p.patient_mobile).toLowerCase().includes(q.toLowerCase()))
  return <><h1>Patients</h1><input placeholder="Search name or mobile…" value={q} onChange={e=>setQ(e.target.value)}/>{err&&<p className="err">{err}</p>}
    {rows===null?<p className="muted pad">Loading patients…</p>:!list.length?<p className="muted pad">No patients found.</p>:list.map(p=><div className="bk" key={p.patient_mobile} style={{gridTemplateColumns:'1fr'}}><div className="bki"><b>{p.patient_name}</b>
      <p className="muted">📞 {p.patient_mobile} · {p.patient_age} yrs · {p.patient_gender} · {p.visits} booking(s) · last {fmtDate(p.booking_date)}</p></div></div>)}</>
}
