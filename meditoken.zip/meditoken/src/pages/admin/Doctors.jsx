import { useEffect, useState } from 'react'
import { supabase } from '../../supabase.js'
import { schedText } from '../../utils.js'
const TABS = [['pending','Pending'],['approved','Approved'],['rejected','Rejected'],['active','Active'],['inactive','Inactive'],['all','All']]
export default function Doctors(){
  const [rows,setRows] = useState(null), [tab,setTab] = useState('pending'), [open,setOpen] = useState(null), [edit,setEdit] = useState(null), [err,setErr] = useState(''), [busy,setBusy] = useState(false)
  const load = () => supabase.from('doctors').select('*,clinics(name),doctor_schedules(*)').order('created_at',{ascending:false}).then(({data,error})=>{setRows(data||[]);setErr(error?'Could not load doctors.':'')})
  useEffect(()=>{load()},[])
  const patch = async (id,p) => { setBusy(true); setErr(''); const {error} = await supabase.from('doctors').update(p).eq('id',id); setBusy(false); if(error) setErr('Could not update the doctor.'); else { setEdit(null); load() } }
  const show = d => tab==='all'||(tab==='active'?d.is_active:tab==='inactive'?!d.is_active:d.status===tab)
  const list = (rows||[]).filter(show)
  return <><h1>Doctors</h1><div className="days">{TABS.map(([k,l])=><button key={k} className={'tk'+(tab===k?' sel':'')} onClick={()=>setTab(k)}>{l}</button>)}</div>
    {err&&<p className="err">{err}</p>}
    {rows===null?<p className="muted pad">Loading doctors…</p>:!list.length?<p className="muted pad">{tab==='pending'?'No pending doctor registrations.':'No doctors found.'}</p>:list.map(d=><div className="bk" key={d.id} style={{gridTemplateColumns:'1fr'}}>
      <div className="bki"><b>{d.name}</b> <span className={'st st-'+(d.status==='rejected'?'cancelled':d.status==='approved'?'completed':'')}>{d.status}</span> {!d.is_active&&<span className="st st-cancelled">inactive</span>}
        <p className="muted">{d.specialization} · {d.clinics?.name||'—'} · {d.experience} yrs</p>
        {open===d.id&&<div className="muted"><p>🎓 {d.qualification||'—'} · 🪪 License: {d.license_number||'—'}</p><p>📞 {d.mobile||'—'} · ✉️ {d.email||'—'}</p><p>📍 {d.address||'—'}</p><p>📅 {schedText(d)}</p></div>}</div>
      {edit?.id===d.id&&<div className="bcard">{['name','specialization','qualification','mobile'].map(k=><label key={k}>{k}<input value={edit[k]||''} onChange={e=>setEdit({...edit,[k]:e.target.value})}/></label>)}
        <label>experience<input type="number" min="0" value={edit.experience??0} onChange={e=>setEdit({...edit,experience:+e.target.value})}/></label>
        <div className="row2"><button className="btn sm" disabled={busy||edit.name.trim().length<2} onClick={()=>patch(d.id,{name:edit.name.trim(),specialization:edit.specialization,qualification:edit.qualification,mobile:edit.mobile,experience:edit.experience})}>Save</button><button className="btn sm ghost" onClick={()=>setEdit(null)}>Cancel</button></div></div>}
      <div className="acts"><button className="btn sm ghost" onClick={()=>setOpen(open===d.id?null:d.id)}>{open===d.id?'Hide':'View'}</button><button className="btn sm ghost" onClick={()=>setEdit({...d})}>Edit</button>
        {d.status!=='approved'&&<button className="btn sm" disabled={busy} onClick={()=>patch(d.id,{status:'approved'})}>Approve</button>}
        {d.status!=='rejected'&&<button className="btn sm ghost" disabled={busy} onClick={()=>confirm('Reject this doctor?')&&patch(d.id,{status:'rejected'})}>Reject</button>}
        <button className="btn sm ghost" disabled={busy} onClick={()=>patch(d.id,{is_active:!d.is_active})}>{d.is_active?'Deactivate':'Activate'}</button></div></div>)}</>
}
