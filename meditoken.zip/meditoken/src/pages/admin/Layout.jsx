import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../../contexts/AuthContext.jsx'
export default function AdminLayout(){
  const {signOut} = useAuth(), nav = useNavigate()
  const out = async () => { await signOut(); nav('/admin/login') }
  return <div className="dash"><aside className="side">
    {[['dashboard','📊 Dashboard & Reports'],['clinics','🏥 Clinics'],['doctors','🩺 Doctors'],['bookings','🎟️ Bookings'],['patients','👥 Patients'],['settings','⚙️ Token & Site Settings']].map(([p,l])=><NavLink key={p} to={`/admin/${p}`}>{l}</NavLink>)}
    <button onClick={out}>🚪 Logout</button></aside><main><Outlet/></main></div>
}
