import { useState } from 'react'
import { useOutletContext } from 'react-router-dom'
import { supabase } from '../../supabase.js'
import { useAuth } from '../../contexts/AuthContext.jsx'
import { uploadImage } from '../../services/doctor.js'
import { Img } from '../../components.jsx'
export default function Profile(){
  const {doc,reload} = useOutletContext(), {user} = useAuth(), [f,setF] = useState({name:doc.name||'',mobile:doc.mobile||'',specialization:doc.specialization||'',qualification:doc.qualification||'',experience:doc.experience||0,address:doc.address||''})
  const [photo,setPhoto] = useState(doc.photo_url), [msg,setMsg] = useState(''), [busy,setBusy] = useState(false), [up,setUp] = useState(false)
  const set = k => e => setF({...f,[k]:e.target.value})
  const pick = async e => { const file = e.target.files[0]; if(!file) return; setUp(true); setMsg('')
    try{ const url = await uploadImage('doctor-images',user.id,file); const {error} = await supabase.from('doctors').update({photo_url:url}).eq('id',doc.id); if(error) throw error; setPhoto(url); reload() }catch(ex){ setMsg(ex.message||'Upload failed.') } setUp(false) }
  const save = async e => { e.preventDefault(); setMsg('')
    if(f.name.trim().length<2) return setMsg('Please enter your name.')
    if(!/^\+?\d{10,13}$/.test(f.mobile.trim())) return setMsg('This mobile number is not valid.')
    setBusy(true); const {error} = await supabase.from('doctors').update({...f,experience:+f.experience||0}).eq('id',doc.id); setBusy(false)
    if(error) setMsg('Could not save the profile. Please try again.'); else { setMsg('Profile saved.'); reload() } }
  return <><h1>Profile</h1><form className="bcard" onSubmit={save} noValidate>
    <div className="imgbox sq" style={{borderRadius:12}}><Img src={photo} alt={doc.name} emoji="🩺"/></div>
    <label>{up?'Uploading image…':'Change photo (max 2 MB)'}<input type="file" accept="image/*" disabled={up} onChange={pick}/></label>
    <label>Full name<input value={f.name} onChange={set('name')}/></label><label>Mobile<input type="tel" value={f.mobile} onChange={set('mobile')}/></label>
    <label>Specialization<input value={f.specialization} onChange={set('specialization')}/></label><label>Qualification<input value={f.qualification} onChange={set('qualification')}/></label>
    <label>Experience (years)<input type="number" min="0" value={f.experience} onChange={set('experience')}/></label><label>Address<input value={f.address} onChange={set('address')}/></label>
    {msg&&<p className={msg==='Profile saved.'?'info':'err'}>{msg}</p>}<button className="btn" disabled={busy}>{busy?'Saving…':'Save Profile'}</button></form></>
}
