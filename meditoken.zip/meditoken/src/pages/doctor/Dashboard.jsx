import { useEffect, useState } from 'react'
import { useOutletContext } from 'react-router-dom'
import { supabase, today } from '../../supabase.js'
import BookingList from '../../components/BookingList.jsx'
export default function Dashboard(){
  const {doc} = useOutletContext(), [rows,setRows] = useState(null), [up,setUp] = useState(0), [err,setErr] = useState('')
  const load = async () => {
    const a = await supabase.from('bookings').select('*').eq('doctor_id',doc.id).eq('booking_date',today()).order('token_number')
    const b = await supabase.from('bookings').select('id',{count:'exact',head:true}).eq('doctor_id',doc.id).gt('booking_date',today()).neq('booking_status','cancelled')
    if(a.error||b.error) setErr('Could not load bookings. Please try again.'); setRows(a.data||[]); setUp(b.count||0) }
  useEffect(()=>{load()},[])
  const n = s => (rows||[]).filter(r=>r.booking_status===s).length
  return <><h1>Today's Tokens</h1><p className="muted">Welcome, {doc.name}</p>
    <div className="stats">{[['Total',rows?.length??'…'],['Waiting',n('waiting')],['Completed',n('completed')],['Cancelled',n('cancelled')],['Upcoming',up]].map(([k,v])=><div className="stat" key={k}><b>{v}</b>{k}</div>)}</div>
    {err&&<p className="err">{err}</p>}{rows&&<BookingList rows={rows} schedules={doc.doctor_schedules} onChange={load}/>}</>
}
