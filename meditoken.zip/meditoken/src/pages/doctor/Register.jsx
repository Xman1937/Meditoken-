import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../supabase.js'
import { DAYS } from '../../utils.js'
import { ensureDoctor, uploadImage } from '../../services/doctor.js'
export default function Register(){
  const [clinics,setClinics] = useState([]), [done,setDone] = useState(false), [err,setErr] = useState(''), [busy,setBusy] = useState(false), [file,setFile] = useState(null)
  const [f,setF] = useState({name:'',mobile:'',email:'',password:'',qualification:'',specialization:'',experience:'',clinic_id:'',license:'',address:'',start:'10:00',end:'14:00',days:[]})
  useEffect(()=>{supabase.from('clinics').select('id,name').eq('is_active',true).order('name').then(({data})=>setClinics(data||[]))},[])
  const set = k => e => setF({...f,[k]:e.target.value})
  const toggle = i => setF({...f,days:f.days.includes(i)?f.days.filter(x=>x!==i):[...f.days,i]})
  const submit = async e => { e.preventDefault(); setErr('')
    if(f.name.trim().length<2) return setErr('Please enter your full name.')
    if(!/^\+?\d{10,13}$/.test(f.mobile.trim())) return setErr('This mobile number is not valid.')
    if(!/^\S+@\S+\.\S+$/.test(f.email)) return setErr('Please enter a valid email.')
    if(f.password.length<8) return setErr('Password must be at least 8 characters.')
    if(!f.specialization.trim()||!f.qualification.trim()||!f.license.trim()) return setErr('Please fill qualification, specialization and license number.')
    if(!f.clinic_id) return setErr('Please select a clinic.')
    if(!f.days.length) return setErr('Please select at least one available day.')
    if(f.end<=f.start) return setErr('End time must be after start time.')
    setBusy(true)
    try{
      const meta = {name:f.name.trim(),mobile:f.mobile.trim(),specialization:f.specialization.trim(),qualification:f.qualification.trim(),experience:+f.experience||0,clinic_id:f.clinic_id,license:f.license.trim(),address:f.address.trim(),days:f.days,start:f.start,end:f.end}
      const {data,error} = await supabase.auth.signUp({email:f.email.trim(),password:f.password,options:{data:{doctor:meta}}})
      if(error) throw error
      if(data.session){ await ensureDoctor(data.user)
        if(file){ try{ const url = await uploadImage('doctor-images',data.user.id,file); await supabase.from('doctors').update({photo_url:url}).eq('user_id',data.user.id) }catch{} }
        await supabase.auth.signOut() }
      setDone(true)
    }catch(ex){ setErr('Registration could not be completed. This email may already be registered.') }
    setBusy(false) }
  if(done) return <div className="wrap page narrow ctr"><div className="bcard"><h1>Registration submitted</h1><p>Your doctor registration has been submitted. Admin approval is required before you can receive bookings.</p><Link className="btn" to="/doctor/login">Go to Doctor Login</Link></div></div>
  return <div className="wrap page narrow"><h1>Doctor Registration</h1>
  <form className="bcard" onSubmit={submit} noValidate>
    <label>Full name<input value={f.name} onChange={set('name')}/></label>
    <div className="two"><label>Mobile<input type="tel" value={f.mobile} onChange={set('mobile')}/></label><label>Email<input type="email" value={f.email} onChange={set('email')}/></label></div>
    <label>Password (min 8)<input type="password" autoComplete="new-password" value={f.password} onChange={set('password')}/></label>
    <div className="two"><label>Qualification<input value={f.qualification} onChange={set('qualification')}/></label><label>Specialization<input value={f.specialization} onChange={set('specialization')}/></label></div>
    <div className="two"><label>Experience (years)<input type="number" min="0" value={f.experience} onChange={set('experience')}/></label><label>License number<input value={f.license} onChange={set('license')}/></label></div>
    <label>Clinic<select value={f.clinic_id} onChange={set('clinic_id')}><option value="">Select Clinic</option>{clinics.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
    <label>Available days</label><div className="days">{DAYS.map((d,i)=><button type="button" key={d} className={'tk'+(f.days.includes(i)?' sel':'')} onClick={()=>toggle(i)}>{d}</button>)}</div>
    <div className="two"><label>From<input type="time" value={f.start} onChange={set('start')}/></label><label>To<input type="time" value={f.end} onChange={set('end')}/></label></div>
    <label>Address<input value={f.address} onChange={set('address')}/></label>
    <label>Photo (optional, max 2 MB)<input type="file" accept="image/*" onChange={e=>setFile(e.target.files[0]||null)}/></label>
    {err&&<p className="err" role="alert">{err}</p>}
    <button className="btn" disabled={busy}>{busy?'Submitting…':'Submit Registration'}</button>
    <p className="muted ctr">Already registered? <Link className="link" to="/doctor/login">Login</Link></p></form></div>
}
