import { useState } from 'react'
import { useOutletContext } from 'react-router-dom'
import { supabase } from '../../supabase.js'
import { DAYS } from '../../utils.js'
export default function Schedule(){
  const {doc,reload} = useOutletContext(), [msg,setMsg] = useState(''), [busy,setBusy] = useState(false)
  const [rows,setRows] = useState(DAYS.map((_,i)=>{ const s = doc.doctor_schedules.find(x=>x.day_of_week===i)
    return {day:i,on:!!s?.is_active,start:s?.start_time?.slice(0,5)||'10:00',end:s?.end_time?.slice(0,5)||'14:00',limit:s?.token_limit||30} }))
  const up = (i,k,v) => setRows(rows.map(r=>r.day===i?{...r,[k]:v}:r))
  const save = async () => { setMsg('')
    const bad = rows.find(r=>r.on&&(r.end<=r.start||!(+r.limit>0))); if(bad) return setMsg(`Please check ${DAYS[bad.day]}: end time must be after start and tokens at least 1.`)
    setBusy(true)
    const {error} = await supabase.from('doctor_schedules').upsert(rows.map(r=>({doctor_id:doc.id,day_of_week:r.day,start_time:r.start,end_time:r.end,token_limit:+r.limit,is_active:r.on})),{onConflict:'doctor_id,day_of_week'})
    setBusy(false); if(error) setMsg('Could not save the schedule. Please try again.'); else { setMsg('Schedule saved.'); reload() } }
  return <><h1>Schedule</h1><div className="bcard">{rows.map(r=><div className="srow" key={r.day}>
    <label className="chk"><input type="checkbox" checked={r.on} onChange={e=>up(r.day,'on',e.target.checked)}/> {DAYS[r.day]}{!r.on&&' (OFF)'}</label>
    {r.on&&<div className="three"><input type="time" value={r.start} onChange={e=>up(r.day,'start',e.target.value)}/><input type="time" value={r.end} onChange={e=>up(r.day,'end',e.target.value)}/><input type="number" min="1" title="Token limit" value={r.limit} onChange={e=>up(r.day,'limit',e.target.value)}/></div>}</div>)}
    {msg&&<p className={msg==='Schedule saved.'?'info':'err'}>{msg}</p>}<button className="btn" disabled={busy} onClick={save}>{busy?'Saving…':'Save Schedule'}</button></div></>
}
