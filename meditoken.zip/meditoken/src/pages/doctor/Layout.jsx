import { useEffect, useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { supabase } from '../../supabase.js'
import { useAuth } from '../../contexts/AuthContext.jsx'
export default function DoctorLayout(){
  const {user,signOut} = useAuth(), nav = useNavigate(), [doc,setDoc] = useState(undefined)
  const load = () => supabase.from('doctors').select('*,doctor_schedules(*)').eq('user_id',user.id).maybeSingle().then(({data})=>setDoc(data))
  useEffect(()=>{load()},[])
  const out = async () => { await signOut(); nav('/doctor/login') }
  return <div className="dash"><aside className="side">
    <NavLink to="/doctor/dashboard">📊 Dashboard</NavLink><NavLink to="/doctor/bookings">📅 Upcoming Bookings</NavLink>
    <NavLink to="/doctor/schedule">🕒 Schedule</NavLink><NavLink to="/doctor/profile">👤 Profile</NavLink><button onClick={out}>🚪 Logout</button></aside>
    <main>{doc&&doc.status==='pending'&&<p className="info">Your registration is pending admin approval. You will not receive bookings until approved.</p>}
      {doc&&doc.status==='rejected'&&<p className="err">Your registration was rejected. Please contact the clinic admin.</p>}
      {doc===undefined?<p className="muted pad">Loading…</p>:!doc?<p className="err">No doctor profile found for this account.</p>:<Outlet context={{doc,reload:load}}/>}</main></div>
}
