import { useEffect, useState } from 'react'
import { useOutletContext } from 'react-router-dom'
import { supabase, today } from '../../supabase.js'
import BookingList from '../../components/BookingList.jsx'
export default function Bookings(){
  const {doc} = useOutletContext(), [from,setFrom] = useState(today()), [rows,setRows] = useState(null), [err,setErr] = useState('')
  const load = async () => { setRows(null)
    const {data,error} = await supabase.from('bookings').select('*').eq('doctor_id',doc.id).gte('booking_date',from).order('booking_date').order('token_number').limit(200)
    setErr(error?'Could not load bookings. Please try again.':''); setRows(data||[]) }
  useEffect(()=>{load()},[from])
  return <><h1>Upcoming Bookings</h1><label style={{maxWidth:220}}>From date<input type="date" value={from} onChange={e=>e.target.value&&setFrom(e.target.value)}/></label>
    {err&&<p className="err">{err}</p>}{rows===null?<p className="muted pad">Loading bookings…</p>:<BookingList rows={rows} schedules={doc.doctor_schedules} onChange={load} showDate/>}</>
}
