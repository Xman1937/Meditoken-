import { useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../supabase.js'
import { Receipt } from '../components.jsx'
export default function Lookup(){
  const [q,setQ] = useState(''), [res,setRes] = useState(null), [err,setErr] = useState(''), [busy,setBusy] = useState(false)
  const go = async e => { e.preventDefault(); setErr(''); setRes(null)
    if(q.trim().length<8) return setErr('Enter your full mobile number or Booking ID.')
    setBusy(true); const {data,error} = await supabase.rpc('lookup_booking',{p_query:q.trim()}); setBusy(false)
    if(error) setErr('Could not search right now. Please try again.'); else setRes(data) }
  return <div className="wrap page narrow"><h1>Find Your Token</h1>
    <form className="bcard" onSubmit={go}><label>Mobile number or Booking ID<input value={q} onChange={e=>setQ(e.target.value)} placeholder="e.g. 9876543210 or MT-1A2B3C4D"/></label>
    {err&&<p className="err">{err}</p>}<button className="btn" disabled={busy}>{busy?'Searching…':'Find Booking'}</button></form>
    {res&&!res.length&&<p className="muted pad">No bookings found.</p>}
    {res?.map(b=><div key={b.id} style={{marginTop:16}}><Receipt b={b}/><p className="ctr"><Link className="link" to={`/booking-success/${b.id}`}>Open printable receipt</Link></p></div>)}</div>
}
