import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { supabase, today } from '../supabase.js'
import { ClinicCard, Img, State } from '../components.jsx'
export default function Home(){
  const [clinics,setClinics]=useState([]),[docs,setDocs]=useState([]),[f,setF]=useState({clinic:'',doctor:'',date:today()}),[err,setErr]=useState(''),[ld,setLd]=useState(true),nav=useNavigate()
  useEffect(()=>{supabase.from('clinics').select('*,doctors(count)').eq('is_active',true).order('name').then(({data,error})=>{setClinics(data||[]);setErr(error?'Could not load clinics. Please try again.':'');setLd(false)})},[])
  useEffect(()=>{setF(x=>({...x,doctor:''}));if(!f.clinic){setDocs([]);return}
    supabase.from('doctors').select('id,name,specialization').eq('clinic_id',f.clinic).eq('status','approved').eq('is_active',true).then(({data})=>setDocs(data||[]))},[f.clinic])
  const go=e=>{e.preventDefault();nav(`/book?clinic=${f.clinic}&doctor=${f.doctor}&date=${f.date}`)}
  return <>
  <section className="hero"><div className="wrap hgrid"><div>
    <h1>Find Your Doctor &amp; Book Your Token Easily</h1><p className="sub">Quick, simple and hassle-free token booking for nearby clinics.</p>
    <form className="bcard" onSubmit={go}>
      <label>Clinic<select required value={f.clinic} onChange={e=>setF({...f,clinic:e.target.value})}><option value="">Select Clinic</option>{clinics.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
      <label>Doctor<select required value={f.doctor} onChange={e=>setF({...f,doctor:e.target.value})}><option value="">Select Doctor</option>{docs.map(d=><option key={d.id} value={d.id}>{d.name} – {d.specialization}</option>)}</select></label>
      <label>Date<input type="date" required min={today()} value={f.date} onChange={e=>setF({...f,date:e.target.value})}/></label>
      <button className="btn">Book Token Now</button></form></div>
    <div className="collage">{clinics.slice(0,4).map(c=><div key={c.id} className="imgbox"><Img src={c.image_url} alt={c.name}/></div>)}</div></div></section>
  <section className="wrap feats">{[['⏱️','Save Time'],['🏥','Trusted Clinics'],['✅','Verified Doctors'],['🎟️','Easy Token Booking']].map(([i,t])=><div key={t} className="feat"><span>{i}</span>{t}</div>)}</section>
  <section className="wrap"><div className="row2 sp"><h2>Available Clinics</h2><Link className="link" to="/clinics">View All Clinics →</Link></div>
    <State loading={ld} error={err} empty={!ld&&!err&&!clinics.length&&'No clinics available yet.'}/>
    <div className="grid">{clinics.slice(0,6).map(c=><ClinicCard key={c.id} c={c}/>)}</div></section></>
}
