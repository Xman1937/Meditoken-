import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { supabase } from '../supabase.js'
import { Receipt, State } from '../components.jsx'
export default function BookingSuccess(){
  const {bookingId} = useParams(), [b,setB] = useState(null), [st,setSt] = useState('loading')
  useEffect(()=>{supabase.rpc('lookup_booking',{p_query:bookingId}).then(({data,error})=>{ if(error||!data?.length) setSt('none'); else {setB(data[0]);setSt('ok')} })},[bookingId])
  if(st!=='ok') return <div className="wrap"><State loading={st==='loading'} empty={st==='none'&&'Booking not found.'}/></div>
  return <div className="wrap page narrow ctr"><h1 className="noprint">✅ Token Booked Successfully</h1><Receipt b={b}/>
    <div className="row2 noprint" style={{justifyContent:'center',marginTop:16}}><button className="btn" onClick={()=>window.print()}>Print / Download Token</button><Link className="link" to="/">Home</Link></div>
    <p className="muted noprint">In the print dialog choose “Save as PDF” to download.</p></div>
}
