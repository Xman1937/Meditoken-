import { useEffect, useMemo, useState } from 'react'
import { supabase } from '../supabase.js'
import { ClinicCard, State } from '../components.jsx'
export default function Clinics(){
  const [all,setAll]=useState([]),[q,setQ]=useState(''),[loc,setLoc]=useState(''),[err,setErr]=useState(''),[ld,setLd]=useState(true)
  useEffect(()=>{supabase.from('clinics').select('*,doctors(count)').eq('is_active',true).order('name').then(({data,error})=>{setAll(data||[]);setErr(error?'Could not load clinics. Please try again.':'');setLd(false)})},[])
  const locs=useMemo(()=>[...new Set(all.map(c=>c.city))],[all])
  const list=all.filter(c=>c.name.toLowerCase().includes(q.toLowerCase())&&(!loc||c.city===loc))
  return <div className="wrap page"><h1>Clinics</h1>
    <div className="filters"><input placeholder="Search clinic…" value={q} onChange={e=>setQ(e.target.value)}/>
    <select value={loc} onChange={e=>setLoc(e.target.value)}><option value="">All locations</option>{locs.map(l=><option key={l}>{l}</option>)}</select></div>
    <State loading={ld} error={err} empty={!ld&&!err&&!list.length&&'No clinics match your search.'}/>
    <div className="grid">{list.map(c=><ClinicCard key={c.id} c={c}/>)}</div></div>
}
