import { useState } from 'react'
import { Routes, Route, Link, NavLink } from 'react-router-dom'
import Home from './pages/Home.jsx'
import Clinics from './pages/Clinics.jsx'
import ClinicDetail from './pages/ClinicDetail.jsx'
import Book from './pages/Book.jsx'
import BookingSuccess from './pages/BookingSuccess.jsx'
import Lookup from './pages/Lookup.jsx'
import { About, Help, PublicSettings } from './pages/Info.jsx'
import AdminLogin from './pages/admin/Login.jsx'
import AdminLayout from './pages/admin/Layout.jsx'
import AdminDash from './pages/admin/Dashboard.jsx'
import AdminClinics from './pages/admin/Clinics.jsx'
import AdminDoctors from './pages/admin/Doctors.jsx'
import AdminBookings from './pages/admin/Bookings.jsx'
import AdminPatients from './pages/admin/Patients.jsx'
import AdminSettings from './pages/admin/Settings.jsx'
import Protected from './components/Protected.jsx'
import DocRegister from './pages/doctor/Register.jsx'
import DocLogin from './pages/doctor/Login.jsx'
import DoctorLayout from './pages/doctor/Layout.jsx'
import DocDash from './pages/doctor/Dashboard.jsx'
import DocBookings from './pages/doctor/Bookings.jsx'
import DocSchedule from './pages/doctor/Schedule.jsx'
import DocProfile from './pages/doctor/Profile.jsx'

function Header(){
  const [open,setOpen]=useState(false), [more,setMore]=useState(false)
  return <header className="hdr"><div className="wrap row">
    <Link to="/" className="logo"><span className="mark">✚</span><span><b>MediToken</b><small>Book Your Doctor Easily</small></span></Link>
    <nav className={open?'nav open':'nav'} onClick={()=>setOpen(false)}>
      <NavLink to="/">Home</NavLink><NavLink to="/about">About</NavLink>
      <NavLink to="/clinics">Clinics</NavLink><NavLink to="/booking-lookup">Find Token</NavLink><NavLink to="/doctor/login">Register / Login</NavLink>
    </nav>
    <Link to="/book" className="btn">Book Token</Link>
    <div className="rel"><button className="ico" aria-label="Menu" onClick={()=>setMore(!more)}>⋮</button>
      {more&&<div className="menu" onClick={()=>setMore(false)}><Link to="/admin/login">Admin Login</Link><Link to="/doctor/login">Doctor Login</Link><Link to="/settings">Settings</Link><Link to="/help">Help</Link></div>}</div>
    <button className="ico burger" aria-label="Navigation" onClick={()=>setOpen(!open)}>☰</button>
  </div></header>
}
const Info=({t,children})=><div className="wrap page"><h1>{t}</h1><p>{children}</p></div>
export default function App(){
  return <><Header/><Routes>
    <Route path="/" element={<Home/>}/><Route path="/clinics" element={<Clinics/>}/>
    <Route path="/clinic/:clinicId" element={<ClinicDetail/>}/><Route path="/book" element={<Book/>}/><Route path="/booking-success/:bookingId" element={<BookingSuccess/>}/><Route path="/booking-lookup" element={<Lookup/>}/><Route path="/about" element={<About/>}/><Route path="/help" element={<Help/>}/><Route path="/settings" element={<PublicSettings/>}/><Route path="/admin/login" element={<AdminLogin/>}/><Route path="/admin" element={<Protected role="admin"><AdminLayout/></Protected>}><Route path="dashboard" element={<AdminDash/>}/><Route path="clinics" element={<AdminClinics/>}/><Route path="doctors" element={<AdminDoctors/>}/><Route path="bookings" element={<AdminBookings/>}/><Route path="patients" element={<AdminPatients/>}/><Route path="settings" element={<AdminSettings/>}/></Route><Route path="/doctor/register" element={<DocRegister/>}/><Route path="/doctor/login" element={<DocLogin/>}/><Route path="/doctor" element={<Protected role="doctor"><DoctorLayout/></Protected>}><Route path="dashboard" element={<DocDash/>}/><Route path="bookings" element={<DocBookings/>}/><Route path="schedule" element={<DocSchedule/>}/><Route path="profile" element={<DocProfile/>}/></Route>
    
    
    <Route path="*" element={<Info t="Page not found">This page does not exist.</Info>}/>
  </Routes><footer className="foot">© MediToken</footer></>
}
