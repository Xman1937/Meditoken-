import { Link } from 'react-router-dom'
import { hours, schedText, t12, fmtDate } from './utils.js'
export const Img=({src,alt,emoji='🏥'})=>src?<img src={src} alt={alt} loading="lazy"/>:<div className="ph">{emoji}</div>
export const ClinicCard=({c})=><div className="card">
  <div className="imgbox"><Img src={c.image_url} alt={c.name}/></div>
  <div className="body"><h3>{c.name}</h3><p className="muted">📍 {c.city}</p>
  <p className="muted">👨‍⚕️ {c.doctors?.[0]?.count??0} doctors · 🕒 {hours(c)}</p>
  <p>{c.description}</p>
  <div className="row2"><Link className="btn sm" to={`/book?clinic=${c.id}`}>Book Token</Link><Link className="link" to={`/clinic/${c.id}`}>Details</Link></div></div></div>
export const DoctorCard=({d,clinic})=><div className="card">
  <div className="imgbox sq"><Img src={d.photo_url} alt={d.name} emoji="🩺"/></div>
  <div className="body"><h3>{d.name}</h3><p className="muted">{d.specialization} · {d.experience} yrs</p>
  <p className="muted">📅 {schedText(d)}</p>
  {clinic&&<p className="muted">🏥 {clinic}</p>}
  <Link className="btn sm" to={`/book?clinic=${d.clinic_id}&doctor=${d.id}`}>Book Token</Link></div></div>
export const State=({loading,error,empty})=>loading?<p className="muted pad">Loading…</p>:error?<p className="err pad">{error}</p>:empty?<p className="muted pad">{empty}</p>:null
const pad = n => String(n).padStart(2,'0')
export const Receipt = ({b}) => <div className="receipt">
  <div className="rhead"><b>✚ MediToken</b><span>Token Receipt</span></div>
  <div className="tok">{pad(b.token_number)}</div><p className="muted ctr">Token Number</p>
  {[['Patient',b.patient_name],['Doctor',b.doctor_name],['Clinic',b.clinic_name],['Date',fmtDate(b.booking_date)],['Time',b.start_time?`${t12(b.start_time)} – ${t12(b.end_time)}`:'—'],['Mobile',b.patient_mobile],['Booking ID',b.code],['Status',b.booking_status.replace('_',' ')]]
    .map(([k,v])=><div className="rrow" key={k}><span>{k}</span><b>{v}</b></div>)}</div>
