create extension if not exists pgcrypto;
create table profiles(id uuid primary key default gen_random_uuid(),user_id uuid unique not null references auth.users on delete cascade,role text not null check(role in('admin','doctor')),name text,mobile text,email text,created_at timestamptz default now(),updated_at timestamptz default now());
create table clinics(id uuid primary key default gen_random_uuid(),name text not null,address text,city text not null,state text,phone text,email text,description text,opening_time time,closing_time time,image_url text,is_active boolean default true,created_at timestamptz default now(),updated_at timestamptz default now());
create table doctors(id uuid primary key default gen_random_uuid(),user_id uuid unique references auth.users on delete set null,clinic_id uuid references clinics on delete cascade,name text not null,mobile text,email text,specialization text,qualification text,experience int default 0,license_number text,address text,photo_url text,status text default 'pending' check(status in('pending','approved','rejected')),is_active boolean default true,created_at timestamptz default now(),updated_at timestamptz default now());
create table doctor_schedules(id uuid primary key default gen_random_uuid(),doctor_id uuid not null references doctors on delete cascade,day_of_week int not null check(day_of_week between 0 and 6),start_time time not null,end_time time not null,token_limit int default 30 check(token_limit>0),is_active boolean default true,unique(doctor_id,day_of_week));
create table bookings(id uuid primary key default gen_random_uuid(),clinic_id uuid not null references clinics,doctor_id uuid not null references doctors,booking_date date not null,token_number int not null,patient_name text not null,patient_mobile text not null,patient_age int,patient_gender text check(patient_gender in('male','female','other')),symptoms text,booking_status text default 'booked' check(booking_status in('booked','confirmed','waiting','completed','cancelled','no_show')),created_at timestamptz default now(),updated_at timestamptz default now(),constraint uniq_token unique(doctor_id,booking_date,token_number));
create table token_settings(id int primary key default 1 check(id=1),default_token_limit int default 30,booking_days_ahead int default 30,bookings_open boolean default true);
create table admin_settings(id int primary key default 1 check(id=1),site_name text default 'MediToken',logo_url text,contact_number text,support_email text);
insert into token_settings default values;insert into admin_settings default values;
create or replace function is_admin() returns boolean language sql security definer stable as $$ select exists(select 1 from profiles where user_id=auth.uid() and role='admin') $$;
create or replace function touch() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end $$;
create trigger t1 before update on clinics for each row execute function touch();
create trigger t2 before update on doctors for each row execute function touch();
create trigger t3 before update on bookings for each row execute function touch();
create trigger t4 before update on profiles for each row execute function touch();
-- doctors can never change their own approval/active state or owner
create or replace function guard_doctor() returns trigger language plpgsql security definer as $$ begin
 if not is_admin() then new.status=old.status;new.is_active=old.is_active;new.user_id=old.user_id;new.clinic_id=old.clinic_id; end if; return new; end $$;
create trigger guard before update on doctors for each row execute function guard_doctor();
alter table profiles enable row level security;alter table clinics enable row level security;alter table doctors enable row level security;alter table doctor_schedules enable row level security;alter table bookings enable row level security;alter table token_settings enable row level security;alter table admin_settings enable row level security;
create policy p_own on profiles for select using(user_id=auth.uid() or is_admin());
create policy p_ins on profiles for insert with check(user_id=auth.uid() and role='doctor');
create policy p_admin on profiles for all using(is_admin()) with check(is_admin());
create policy c_read on clinics for select using(is_active or is_admin());
create policy c_admin on clinics for all using(is_admin()) with check(is_admin());
create policy d_read on doctors for select using((status='approved' and is_active) or user_id=auth.uid() or is_admin());
create policy d_reg on doctors for insert with check(user_id=auth.uid() and status='pending');
create policy d_own on doctors for update using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy d_admin on doctors for all using(is_admin()) with check(is_admin());
create policy s_read on doctor_schedules for select using(exists(select 1 from doctors d where d.id=doctor_id and((d.status='approved' and d.is_active) or d.user_id=auth.uid())) or is_admin());
create policy s_write on doctor_schedules for all using(is_admin() or exists(select 1 from doctors d where d.id=doctor_id and d.user_id=auth.uid())) with check(is_admin() or exists(select 1 from doctors d where d.id=doctor_id and d.user_id=auth.uid()));
create policy b_read on bookings for select using(is_admin() or exists(select 1 from doctors d where d.id=doctor_id and d.user_id=auth.uid()));
create policy b_upd on bookings for update using(is_admin() or exists(select 1 from doctors d where d.id=doctor_id and d.user_id=auth.uid()));
revoke insert,delete on bookings from anon,authenticated;revoke update on bookings from anon,authenticated;grant update(booking_status) on bookings to authenticated;
create policy ts_read on token_settings for select using(true);create policy ts_admin on token_settings for all using(is_admin()) with check(is_admin());
create policy as_read on admin_settings for select using(true);create policy as_admin on admin_settings for all using(is_admin()) with check(is_admin());
-- Public token board: schedule + which token numbers are taken (no patient data)
create or replace function get_token_board(p_doctor uuid,p_date date) returns json language plpgsql security definer stable as $$
declare s doctor_schedules;
begin
 select s2.* into s from doctor_schedules s2 join doctors d on d.id=s2.doctor_id where s2.doctor_id=p_doctor and s2.day_of_week=extract(dow from p_date)::int and s2.is_active and d.status='approved' and d.is_active;
 if not found then return null; end if;
 return json_build_object('limit',s.token_limit,'start',s.start_time,'end',s.end_time,'booked',coalesce((select json_agg(token_number order by token_number) from bookings where doctor_id=p_doctor and booking_date=p_date),'[]'::json));
end $$;
-- Race-safe booking: the unique(doctor_id,booking_date,token_number) constraint is the final guard
create or replace function book_token(p_doctor uuid,p_date date,p_token int,p_name text,p_mobile text,p_age int,p_gender text,p_symptoms text) returns uuid language plpgsql security definer as $$
declare d doctors; s doctor_schedules; ts token_settings; nid uuid;
begin
 select * into ts from token_settings; if not ts.bookings_open then raise exception 'NOT_AVAILABLE'; end if;
 select * into d from doctors where id=p_doctor and status='approved' and is_active; if not found then raise exception 'NOT_AVAILABLE'; end if;
 select * into s from doctor_schedules where doctor_id=p_doctor and day_of_week=extract(dow from p_date)::int and is_active; if not found then raise exception 'NOT_AVAILABLE'; end if;
 if p_date<current_date or p_date>current_date+ts.booking_days_ahead then raise exception 'INVALID_DATE'; end if;
 if p_token<1 or p_token>s.token_limit then raise exception 'INVALID_TOKEN'; end if;
 if length(trim(coalesce(p_name,'')))<2 or p_age is null or p_age<0 or p_age>120 or p_gender not in('male','female','other') then raise exception 'INVALID_DETAILS'; end if;
 if p_mobile !~ '^\+?[0-9]{10,13}$' then raise exception 'INVALID_MOBILE'; end if;
 begin
  insert into bookings(clinic_id,doctor_id,booking_date,token_number,patient_name,patient_mobile,patient_age,patient_gender,symptoms) values(d.clinic_id,p_doctor,p_date,p_token,trim(p_name),p_mobile,p_age,p_gender,nullif(trim(p_symptoms),'')) returning id into nid;
 exception when unique_violation then raise exception 'TOKEN_TAKEN'; end;
 return nid;
end $$;
-- Lookup by mobile number or Booking ID only; returns matching rows, nothing else
create or replace function lookup_booking(p_query text) returns table(id uuid,code text,token_number int,patient_name text,patient_mobile text,booking_date date,booking_status text,doctor_name text,clinic_name text,start_time time,end_time time) language sql security definer stable as $$
 select b.id,'MT-'||upper(left(replace(b.id::text,'-',''),8)),b.token_number,b.patient_name,b.patient_mobile,b.booking_date,b.booking_status,d.name,c.name,s.start_time,s.end_time
 from bookings b join doctors d on d.id=b.doctor_id join clinics c on c.id=b.clinic_id left join doctor_schedules s on s.doctor_id=b.doctor_id and s.day_of_week=extract(dow from b.booking_date)::int
 where length(trim(p_query))>=8 and(b.patient_mobile=trim(p_query) or b.id::text=trim(p_query) or 'MT-'||upper(left(replace(b.id::text,'-',''),8))=upper(trim(p_query)))
 order by b.booking_date desc limit 20 $$;
grant execute on function get_token_board,book_token,lookup_booking to anon,authenticated;
-- Storage
insert into storage.buckets(id,name,public) values('clinic-images','clinic-images',true),('doctor-images','doctor-images',true) on conflict do nothing;
create policy img_read on storage.objects for select using(bucket_id in('clinic-images','doctor-images'));
create policy img_admin on storage.objects for all using(bucket_id in('clinic-images','doctor-images') and is_admin()) with check(bucket_id in('clinic-images','doctor-images') and is_admin());
create policy img_doc on storage.objects for all using(bucket_id='doctor-images' and (storage.foldername(name))[1]=auth.uid()::text) with check(bucket_id='doctor-images' and (storage.foldername(name))[1]=auth.uid()::text);
