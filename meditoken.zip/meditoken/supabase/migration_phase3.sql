-- Run once in the Supabase SQL editor (adds the doctor address field)
alter table doctors add column if not exists address text;
