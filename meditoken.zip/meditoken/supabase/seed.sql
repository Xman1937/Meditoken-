-- OPTIONAL SAMPLE DATA for testing only. Do not run on a production database. Bookings are never seeded.
insert into clinics(name,address,city,state,phone,email,description,opening_time,closing_time) values
('City Care Clinic','12 Main Street','Downtown','State','+1 555 0101','care@example.com','General and family medicine in the heart of the city.','09:00','18:00'),
('Green Valley Health Center','48 Park Avenue','Green Valley','State','+1 555 0102','info@example.com','Modern multi-specialty center with friendly staff.','08:00','20:00');
insert into doctors(clinic_id,name,specialization,qualification,experience,status) select id,'Dr. Anita Rao','General Physician','MBBS, MD',12,'approved' from clinics where name='City Care Clinic';
insert into doctors(clinic_id,name,specialization,qualification,experience,status) select id,'Dr. Sam Patel','Pediatrician','MBBS, DCH',8,'approved' from clinics where name like 'Green%';
insert into doctor_schedules(doctor_id,day_of_week,start_time,end_time,token_limit) select d.id,g,'10:00','14:00',20 from doctors d,generate_series(1,5) g where d.name='Dr. Anita Rao';
insert into doctor_schedules(doctor_id,day_of_week,start_time,end_time,token_limit) select d.id,g,'16:00','20:00',15 from doctors d,unnest(array[1,3,5,6]) g where d.name='Dr. Sam Patel';
